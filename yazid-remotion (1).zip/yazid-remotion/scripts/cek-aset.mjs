import fs from 'node:fs';
const wajib = [
  'public/images/1000520810.jpg',
  'public/images/1000520811.jpg',
  'public/images/1000520814.jpg',
  'public/images/1000520815.jpg',
  'public/images/1000520816.jpg',
  'public/images/1000520817.jpg',
  'public/images/1000520818.jpg',
  'public/images/1000520819.jpg',
  'public/images/1000520820.jpg',
  'public/audio/AUD-20261102-WA0013.mp3',
];
const hilang = wajib.filter((f) => !fs.existsSync(f));
if (hilang.length) {
  console.error('ASET BELUM LENGKAP. Salin file berikut ke folder proyek:\n - ' + hilang.join('\n - '));
  process.exit(1);
}
console.log('Semua aset lengkap (' + wajib.length + ' file).');
