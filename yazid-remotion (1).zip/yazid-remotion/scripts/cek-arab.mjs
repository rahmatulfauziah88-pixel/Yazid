import fs from 'node:fs';
const a = JSON.parse(fs.readFileSync('src/data/arab.json', 'utf8'));
const joined = a.segments.join(' ');
if (joined !== a.full) {
  console.error('GAGAL: potongan teks Arab tidak sama persis dengan teks utuh.');
  process.exit(1);
}
const expected = 'أخرج الواقدي من طرق: أن عبد الله بن حنظلة الغسيل قال: والله؛ ما خرجنا على يزيد .. حتى خفنا أن نرمى بالحجارة من السماء: أن رجلا ينكح أمهات الأولاد، والبنات، والأخوات، ويشرب الخمر، ويدع الصلاة؟!';
console.log('Teks Arab utuh sama dengan potongan:', joined === a.full);
console.log('Jumlah karakter:', [...a.full].length);
