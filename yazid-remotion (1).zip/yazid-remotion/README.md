# Dokumenter Yazid bin Muawiyah (Remotion, 1080x1920, 30 FPS)

## 1. Pasang aset (wajib)
- 9 gambar -> `public/images/` (1000520810.jpg, ...11, ...14 sampai ...20)
- Audio -> `public/audio/AUD-20261102-WA0013.mp3`
Cek: `npm run cek`

## 2. Kalibrasi peta (penting)
Posisi titik dihitung dari koordinat asli lewat transformasi yang dicocokkan ke gambar peta (foto udara miring).
`npm run kalibrasi` -> lihat `out/kalibrasi-peta.png`. Titik merah harus tepat di Damaskus, Karbala, Madinah, Makkah.
Jika meleset, atur `MANUAL_POS` di `src/config.ts`.

## 3. Uji huruf Arab
`npm run uji-arab` -> `out/uji-arab.png`. Pastikan huruf tersambung dan terbaca kanan ke kiri.

## 4. Sinkron narasi
Durasi video otomatis mengikuti audio. Pembagian adegan otomatis proporsional jumlah kata.
Awal tiap adegan sudah diatur dari jeda audio (`MANUAL_START_SECONDS` di `src/config.ts`); geser jika perlu.

## 5. Render
`npm run render` -> `out/yazid.mp4`, atau jalankan workflow GitHub Actions "Render Yazid".

Catatan: font diambil dari Google Fonts saat render (butuh internet). Jangan beri letterSpacing pada teks Arab.
