import React from 'react';
import {Composition, Still, staticFile} from 'remotion';
import {getAudioDurationInSeconds} from '@remotion/media-utils';
import {Video} from './Video';
import {MapKalibrasi} from './Kalibrasi';
import {UjiArab} from './UjiArab';
import {AUDIO_FILE, FALLBACK_SECONDS, TAIL_FRAMES} from './config';
import {FPS, H, W} from './theme';

export const Root: React.FC = () => (
  <>
    <Composition
      id="YazidDokumenter"
      component={Video}
      width={W}
      height={H}
      fps={FPS}
      durationInFrames={FALLBACK_SECONDS * FPS}
      calculateMetadata={async () => {
        let seconds = FALLBACK_SECONDS;
        try {
          seconds = await getAudioDurationInSeconds(staticFile(AUDIO_FILE));
        } catch (e) {
          console.warn('Durasi audio gagal dibaca, memakai durasi cadangan.', e);
        }
        return {durationInFrames: Math.ceil(seconds * FPS) + TAIL_FRAMES};
      }}
    />
    <Still id="MapKalibrasi" component={MapKalibrasi} width={W} height={H} />
    <Still id="UjiArab" component={UjiArab} width={W} height={H} />
  </>
);
