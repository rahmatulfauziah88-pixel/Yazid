import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Book} from '../components/Book';
import {ArabicText, QuotePage} from '../components/ArabicQuote';
import {Anchor, GoldRule, SubText, TitleText} from '../components/Text';
import {Show, fr} from '../components/Timing';
import {Sequence} from 'remotion';
import {arab} from '../config';
import {C, SAFE_TOP} from '../theme';
import {FONT_TITLE} from '../fonts';

if (arab.segments.join(' ') !== arab.full) {
  throw new Error('Teks Arab terpotong tidak sama persis dengan teks utuh. Periksa src/data/arab.json');
}

const Badge: React.FC = () => (
  <div
    style={{
      position: 'absolute',
      top: SAFE_TOP,
      left: 70,
      right: 70,
      textAlign: 'center',
      fontFamily: FONT_TITLE,
      fontSize: 27,
      letterSpacing: 4,
      color: C.gold,
      padding: '12px 10px',
      border: `1.5px solid ${C.goldDim}`,
      background: 'rgba(10,7,4,0.7)',
    }}
  >
    RIWAYAT YANG DIKUTIP SUMBER SEJARAH
  </div>
);

export const Scene6Suyuthi: React.FC<{dur: number}> = ({dur}) => {
  const tTitle = fr(dur, 0.18);
  const pageDur = fr(dur, 0.18);
  const pages = [0, 1, 2].map((i) => ({
    from: tTitle + i * pageDur,
    segs: arab.segments.slice(i * 2, i * 2 + 2),
    tr: arab.translations[i],
  }));
  const tEnd = tTitle + 3 * pageDur;
  return (
    <AbsoluteFill>
      <Book dur={tTitle + 10} zoomTo={2.3} darken={{from: fr(dur, 0.1), to: tTitle, level: 0.55}}>
        {/* judul kitab */}
        <Show from={fr(dur, 0.01)} to={tTitle - 4} fade={14}>
          <Anchor at="center" offset={-60}>
            <ArabicText text={arab.title} size={120} color={C.gold} glow />
            <GoldRule />
            <TitleText text="TARIKH AL-KHULAFA" size={62} spacing={5} />
            <TitleText text="IMAM JALALUDDIN AL-SUYUTHI" size={40} color={C.gold} spacing={4} />
          </Anchor>
        </Show>
        {/* halaman kutipan */}
        {pages.map((p, i) => (
          <Sequence key={i} from={p.from} durationInFrames={pageDur + (i === 2 ? 0 : 6)} layout="none">
            <div style={{position: 'absolute', inset: 0}}>
              <QuotePage segments={p.segs} translation={p.tr} dur={pageDur} />
            </div>
          </Sequence>
        ))}
        <Show from={tTitle} to={tEnd} fade={10}>
          <Badge />
          <Anchor at="bottom">
            <SubText text="Tarikh al-Khulafa — Imam Jalaluddin al-Suyuthi" size={34} color={C.gold} />
          </Anchor>
        </Show>
        {/* penutup keterangan sumber */}
        <Show from={tEnd} fade={16}>
          <Anchor at="center" offset={-40}>
            <TitleText text="RIWAYAT YANG DIKUTIP" size={50} color={C.gold} spacing={5} />
            <GoldRule />
            <SubText text="Melalui jalur al-Waqidi, dinisbatkan kepada Abdullah bin Hanzalah al-Ghasil." size={42} />
            <SubText text="Disajikan sebagai riwayat atau tuduhan yang dikutip sumber sejarah, bukan fakta yang terbukti secara independen." size={38} color={C.parchment} />
            <GoldRule width={300} />
            <TitleText text="AL-DZAHABI" size={44} color={C.gold} spacing={6} pop={false} />
            <SubText text="dinukil oleh al-Suyuthi" size={36} />
          </Anchor>
        </Show>
      </Book>
    </AbsoluteFill>
  );
};
