import React from 'react';
import {AbsoluteFill} from 'remotion';
import {MapLayer} from '../components/MapLayer';
import {Illustration} from '../components/Illustration';
import {Anchor, GoldRule, TitleText, YearBadge, SubText} from '../components/Text';
import {Phase, Show, fr} from '../components/Timing';
import {IMG, placeNorm} from '../config';

export const Scene2Yazid: React.FC<{dur: number}> = ({dur}) => {
  const d = placeNorm('damaskus');
  const t2 = fr(dur, 0.55);
  return (
    <AbsoluteFill>
      <Phase from={0}>
        <AbsoluteFill>
          <MapLayer
            cam={[
              {t: 0, at: {x: 0.55, y: 0.6}, z: 1.4},
              {t: t2, at: d, z: 2.7},
            ]}
            markers={[{id: 'damaskus', at: fr(dur, 0.04)}]}
            regions={[{text: 'SYAM', x: d.x - 0.02, y: d.y - 0.075, at: fr(dur, 0.1)}]}
          />
          <Show from={fr(dur, 0.06)} fade={12}>
            <Anchor at="top" offset={20}>
              <YearBadge year="60 H" />
            </Anchor>
          </Show>
        </AbsoluteFill>
      </Phase>
      <Phase from={t2} fade={26}>
        <Illustration src={IMG.damaskus} dur={dur - t2} from={{s: 1.08, x: 0, y: 70}} to={{s: 1.2, x: -50, y: -70}}>
          <Anchor at="bottom">
            <GoldRule />
            <TitleText text="DAMASKUS" size={72} />
            <SubText text="Syam · 60 H" />
          </Anchor>
        </Illustration>
      </Phase>
    </AbsoluteFill>
  );
};
