import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {MapLayer} from '../components/MapLayer';
import {Anchor, GoldRule, SubText, TitleText, YearBadge} from '../components/Text';
import {Show, fr} from '../components/Timing';
import {placeNorm} from '../config';
import {C} from '../theme';
import {FONT_TITLE} from '../fonts';

const Icon: React.FC<{kind: 'komentar' | 'like' | 'bagikan' | 'ikuti'}> = ({kind}) => {
  const p = {fill: 'none', stroke: C.gold, strokeWidth: 5, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  return (
    <svg width="90" height="90" viewBox="0 0 64 64">
      {kind === 'komentar' && <path {...p} d="M8 12h48v32H28l-12 10V44H8z" />}
      {kind === 'like' && <path {...p} d="M32 54C10 38 8 22 18 16c6-3 11 0 14 6 3-6 8-9 14-6 10 6 8 22-14 38z" />}
      {kind === 'bagikan' && <path {...p} d="M34 8l22 20-22 20V36C18 36 10 42 6 54c0-18 8-30 28-32z" />}
      {kind === 'ikuti' && <path {...p} d="M32 12v40M12 32h40" />}
    </svg>
  );
};

const CTA: React.FC<{delay?: number; items: {kind: 'komentar' | 'like' | 'bagikan' | 'ikuti'; label: string}[]}> = ({items, delay = 0}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div style={{display: 'flex', gap: 44, justifyContent: 'center'}}>
      {items.map((it, i) => {
        const s = spring({frame: frame - delay - i * 14, fps, config: {damping: 13}});
        return (
          <div key={it.kind} style={{textAlign: 'center', transform: `scale(${s})`, opacity: s}}>
            <div style={{width: 150, height: 150, borderRadius: '50%', border: `3px solid ${C.gold}`, background: 'rgba(10,7,4,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 30px rgba(201,162,74,0.3)'}}>
              <Icon kind={it.kind} />
            </div>
            <div style={{fontFamily: FONT_TITLE, fontSize: 28, color: C.sand, letterSpacing: 3, marginTop: 14}}>{it.label}</div>
          </div>
        );
      })}
    </div>
  );
};

export const Scene8Penutup: React.FC<{dur: number}> = ({dur}) => {
  const frame = useCurrentFrame();
  const k = placeNorm('makkah');
  const tQ = fr(dur, 0.31), tC = fr(dur, 0.44), tF = fr(dur, 0.9);
  const black = interpolate(frame, [fr(dur, 0.1), fr(dur, 0.3), tF - 6, tF + 20], [0, 0.72, 0.72, 1], {extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{background: C.black}}>
      <MapLayer
        cam={[
          {t: 0, at: k, z: 2.8},
          {t: fr(dur, 0.3), at: {x: 0.5, y: 0.5}, z: 1},
        ]}
        markers={[{id: 'makkah', at: 0, hideSub: true}]}
      />
      <AbsoluteFill style={{background: '#000', opacity: black}} />
      <Show from={4} to={fr(dur, 0.12)} fade={8}>
        <Anchor at="top" offset={20}>
          <YearBadge year="64 H" />
        </Anchor>
      </Show>
      <Show from={fr(dur, 0.14)} to={tQ - 6} fade={16}>
        <Anchor at="center">
          <GoldRule />
          <TitleText text="LUKA SEJARAH TETAP DIKENANG." size={76} color={C.sand} spacing={4} />
          <GoldRule />
        </Anchor>
      </Show>
      <Show from={tQ} to={tC - 6} fade={16}>
        <Anchor at="center">
          <TitleText text="BAGAIMANA KITA MEMAHAMI SEJARAH INI?" size={70} color={C.gold} spacing={4} />
        </Anchor>
      </Show>
      <Show from={tC} to={tF - 8} fade={16}>
        <Anchor at="center">
          <CTA
            items={[
              {kind: 'komentar', label: 'KOMENTAR'},
              {kind: 'like', label: 'LIKE'},
            ]}
          />
          <div style={{height: 20}} />
          <CTA
            delay={28}
            items={[
              {kind: 'bagikan', label: 'BAGIKAN'},
              {kind: 'ikuti', label: 'IKUTI'},
            ]}
          />
          <div style={{height: 10}} />
          <SubText text="Tulis pendapat dan referensi kitabmu di kolom komentar." size={40} />
        </Anchor>
      </Show>
      <Show from={tF} fade={24}>
        <Anchor at="center">
          <GoldRule />
          <TitleText text="KARENA SEJARAH TIDAK BOLEH DILUPAKAN." size={72} color={C.gold} spacing={4} />
          <GoldRule />
        </Anchor>
      </Show>
    </AbsoluteFill>
  );
};
