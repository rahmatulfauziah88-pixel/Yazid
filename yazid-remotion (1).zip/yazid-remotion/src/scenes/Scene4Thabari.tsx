import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Book} from '../components/Book';
import {Anchor, GoldRule, SubText, TitleText} from '../components/Text';
import {Show, fr} from '../components/Timing';
import {C} from '../theme';

export const Scene4Thabari: React.FC<{dur: number}> = ({dur}) => (
  <AbsoluteFill>
    <Book dur={dur} zoomTo={1.35}>
      <Show from={fr(dur, 0.05)} to={fr(dur, 0.68)} fade={16}>
        <Anchor at="center" offset={-60}>
          <SubText text="SUMBER SEJARAH" size={34} color={C.gold} />
          <GoldRule />
          <TitleText text="TARIKH AL-RUSUL WA AL-MULUK" size={60} spacing={5} />
          <GoldRule width={300} />
          <TitleText text="IMAM AL-THABARI" size={50} color={C.gold} spacing={7} />
        </Anchor>
      </Show>
      <Show from={fr(dur, 0.72)} fade={16}>
        <Anchor at="center">
          <TitleText text="NAMUN, TRAGEDI BELUM BERAKHIR." size={58} color={C.sand} spacing={4} />
        </Anchor>
      </Show>
    </Book>
  </AbsoluteFill>
);
