import React from 'react';
import {AbsoluteFill} from 'remotion';
import {MapLayer} from '../components/MapLayer';
import {Illustration} from '../components/Illustration';
import {Anchor, GoldRule, SubText, TitleText, YearBadge} from '../components/Text';
import {Phase, Show, fr} from '../components/Timing';
import {IMG, placeNorm} from '../config';

export const Scene3Karbala: React.FC<{dur: number}> = ({dur}) => {
  const d = placeNorm('damaskus');
  const k = placeNorm('karbala');
  const t2 = fr(dur, 0.25);
  const t3 = fr(dur, 0.62);
  return (
    <AbsoluteFill>
      <Phase from={0}>
        <AbsoluteFill>
          <MapLayer
            cam={[
              {t: 0, at: d, z: 2.6},
              {t: fr(dur, 0.1), at: {x: (d.x + k.x) / 2, y: (d.y + k.y) / 2}, z: 1.7},
              {t: t2, at: k, z: 2.8},
            ]}
            markers={[
              {id: 'damaskus', at: 0, hideSub: true},
              {id: 'karbala', at: fr(dur, 0.07)},
            ]}
          />
          <Show from={fr(dur, 0.03)} fade={12}>
            <Anchor at="top" offset={20}>
              <YearBadge year="61 H" />
            </Anchor>
          </Show>
          <Show from={fr(dur, 0.13)} fade={12}>
            <Anchor at="bottom">
              <GoldRule />
              <TitleText text="ASYURA — KARBALA" size={62} />
            </Anchor>
          </Show>
        </AbsoluteFill>
      </Phase>
      <Phase from={t2} fade={26}>
        <Illustration src={IMG.kemah} dur={t3 - t2 + 20} from={{s: 1.06, x: 0, y: 40}} to={{s: 1.22, x: 30, y: -30}}>
          <Anchor at="bottom">
            <GoldRule />
            <TitleText text="ASYURA — KARBALA" size={62} pop={false} />
            <SubText text="61 H" />
          </Anchor>
        </Illustration>
      </Phase>
      <Phase from={t3} fade={28}>
        <Illustration src={IMG.pasukan} dur={dur - t3} from={{s: 1.2, x: 20, y: -20}} to={{s: 1.05, x: -10, y: 30}}>
          <Anchor at="bottom">
            <GoldRule />
            <TitleText text="ASYURA — KARBALA" size={62} pop={false} />
            <SubText text="61 H" />
          </Anchor>
        </Illustration>
      </Phase>
    </AbsoluteFill>
  );
};
