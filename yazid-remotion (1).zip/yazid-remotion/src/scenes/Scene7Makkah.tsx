import React from 'react';
import {AbsoluteFill} from 'remotion';
import {MapLayer} from '../components/MapLayer';
import {Illustration} from '../components/Illustration';
import {Anchor, GoldRule, SubText, TitleText, YearBadge} from '../components/Text';
import {Phase, Show, fr} from '../components/Timing';
import {IMG, placeNorm} from '../config';

export const Scene7Makkah: React.FC<{dur: number}> = ({dur}) => {
  const m = placeNorm('madinah');
  const k = placeNorm('makkah');
  const t2 = fr(dur, 0.25);
  const t3 = fr(dur, 0.6);
  return (
    <AbsoluteFill>
      <Phase from={0}>
        <AbsoluteFill>
          <MapLayer
            cam={[
              {t: 0, at: m, z: 2.2},
              {t: t2, at: k, z: 3.2},
            ]}
            markers={[
              {id: 'madinah', at: 0, hideSub: true},
              {id: 'makkah', at: fr(dur, 0.05)},
            ]}
          />
          <Show from={fr(dur, 0.07)} fade={12}>
            <Anchor at="top" offset={20}>
              <YearBadge year="64 H" />
            </Anchor>
          </Show>
          <Show from={fr(dur, 0.1)} fade={12}>
            <Anchor at="bottom">
              <GoldRule />
              <TitleText text="PENGEPUNGAN MAKKAH" size={58} />
            </Anchor>
          </Show>
        </AbsoluteFill>
      </Phase>
      <Phase from={t2} fade={26}>
        <Illustration src={IMG.makkah} dur={t3 - t2 + 20} from={{s: 1.05, x: 0, y: 30}} to={{s: 1.22, x: 0, y: -40}}>
          <Anchor at="bottom">
            <GoldRule />
            <TitleText text="PENGEPUNGAN MAKKAH" size={58} pop={false} />
            <SubText text="64 H" />
          </Anchor>
        </Illustration>
      </Phase>
      <Phase from={t3} fade={34}>
        <Illustration src={IMG.kaabah} dur={dur - t3} from={{s: 1.04, x: 0, y: 20}} to={{s: 1.14, x: 0, y: -20}} warm={0.1}>
          <Anchor at="bottom">
            <GoldRule />
            <TitleText text="KA'BAH" size={72} />
            <SubText text="Masjidil Haram" />
          </Anchor>
        </Illustration>
      </Phase>
    </AbsoluteFill>
  );
};
