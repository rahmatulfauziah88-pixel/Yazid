import React from 'react';
import {AbsoluteFill} from 'remotion';
import {MapLayer} from '../components/MapLayer';
import {Illustration} from '../components/Illustration';
import {Anchor, GoldRule, SubText, TitleText, YearBadge} from '../components/Text';
import {Phase, Show, fr} from '../components/Timing';
import {IMG, placeNorm} from '../config';

export const Scene5Harrah: React.FC<{dur: number}> = ({dur}) => {
  const m = placeNorm('madinah');
  const d = placeNorm('damaskus');
  const mid = {x: (m.x + d.x) / 2, y: (m.y + d.y) / 2};
  const t2 = fr(dur, 0.46);
  const t3 = fr(dur, 0.8);
  return (
    <AbsoluteFill>
      <Phase from={0}>
        <AbsoluteFill>
          <MapLayer
            cam={[
              {t: 0, at: {x: 0.5, y: 0.6}, z: 1.2},
              {t: fr(dur, 0.1), at: m, z: 3.0},
              {t: fr(dur, 0.17), at: m, z: 3.0},
              {t: fr(dur, 0.32), at: mid, z: 1.9},
            ]}
            markers={[
              {id: 'madinah', at: fr(dur, 0.03)},
              {id: 'harrah', at: fr(dur, 0.09), ring: true},
              {id: 'damaskus', at: fr(dur, 0.22), hideSub: true},
            ]}
            routes={[{from: 'damaskus', to: 'madinah', start: fr(dur, 0.24), end: fr(dur, 0.42), bend: 0.12}]}
          />
          <Show from={fr(dur, 0.07)} to={fr(dur, 0.44)} fade={12}>
            <Anchor at="top" offset={20}>
              <YearBadge year="63 H" />
            </Anchor>
          </Show>
          <Show from={fr(dur, 0.26)} fade={12}>
            <Anchor at="bottom">
              <SubText text="Arah pergerakan — ilustratif, bukan jalur pasti" size={36} />
            </Anchor>
          </Show>
        </AbsoluteFill>
      </Phase>
      <Phase from={t2} fade={26}>
        <Illustration src={IMG.permukiman} dur={t3 - t2 + 20} from={{s: 1.1, x: 0, y: 60}} to={{s: 1.22, x: -40, y: -40}}>
          <Anchor at="bottom">
            <GoldRule />
            <TitleText text="PERISTIWA AL-HARRAH" size={56} />
            <SubText text="Madinah · 63 H" />
          </Anchor>
        </Illustration>
      </Phase>
      <Phase from={t3} fade={26}>
        <Illustration src={IMG.kotaDitinggal} dur={dur - t3} from={{s: 1.06, x: 20, y: 0}} to={{s: 1.2, x: -20, y: -40}}>
          <Anchor at="bottom">
            <GoldRule />
            <TitleText text="PERISTIWA AL-HARRAH" size={56} pop={false} />
            <SubText text="Madinah · 63 H" />
          </Anchor>
        </Illustration>
      </Phase>
    </AbsoluteFill>
  );
};
