import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {MapLayer, CamKey} from '../components/MapLayer';
import {Anchor, GoldRule, SubText, TitleText} from '../components/Text';
import {Show, fr} from '../components/Timing';
import {placeNorm} from '../config';
import {C} from '../theme';

const avg = () => {
  const ids = ['karbala', 'madinah', 'makkah', 'damaskus'] as const;
  const pts = ids.map(placeNorm);
  return {x: pts.reduce((a, p) => a + p.x, 0) / pts.length, y: pts.reduce((a, p) => a + p.y, 0) / pts.length};
};

export const Scene1Hook: React.FC<{dur: number}> = ({dur}) => {
  const frame = useCurrentFrame();
  const black = interpolate(frame, [0, 14], [1, 0], {extrapolateRight: 'clamp'});
  const cam: CamKey[] = [
    {t: 0, at: {x: 0.5, y: 0.5}, z: 1},
    {t: dur, at: avg(), z: 1.55},
  ];
  const tK = fr(dur, 0.1), tM = fr(dur, 0.33), tX = fr(dur, 0.5);
  return (
    <AbsoluteFill>
      <MapLayer
        cam={cam}
        markers={[
          {id: 'karbala', at: tK},
          {id: 'madinah', at: tM},
          {id: 'makkah', at: tX},
        ]}
      />
      <AbsoluteFill style={{background: '#000', opacity: black}} />
      {/* HOOK */}
      <Show from={2} to={tK - 4} fade={8}>
        <Anchor at="center" offset={-120}>
          <TitleText text="BAYANGKAN..." size={118} color={C.gold} spacing={10} />
        </Anchor>
      </Show>
      <Show from={tK} to={tM - 6} fade={12}>
        <Anchor at="bottom">
          <TitleText text="KARBALA" size={84} />
          <SubText text="Cucu Rasulullah ﷺ terbunuh" />
        </Anchor>
      </Show>
      <Show from={tM} to={tX - 6} fade={12}>
        <Anchor at="bottom">
          <TitleText text="MADINAH" size={84} />
          <SubText text="Kota Madinah diserang" />
        </Anchor>
      </Show>
      <Show from={tX} to={fr(dur, 0.78)} fade={12}>
        <Anchor at="bottom">
          <TitleText text="MAKKAH" size={84} />
          <SubText text="Kota suci dikepung" />
        </Anchor>
      </Show>
      <Show from={fr(dur, 0.84)} fade={16}>
        <Anchor at="bottom">
          <GoldRule />
          <TitleText text="YAZID BIN MUAWIYAH" size={64} color={C.gold} spacing={6} />
          <SubText text="Tragedi di Balik Kekuasaan" size={42} />
        </Anchor>
      </Show>
    </AbsoluteFill>
  );
};
