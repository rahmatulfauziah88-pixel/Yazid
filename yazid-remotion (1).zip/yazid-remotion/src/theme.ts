export const W = 1080;
export const H = 1920;
export const FPS = 30;

export const C = {
  black: '#0a0704',
  brown: '#2a1b10',
  brownMid: '#4a3220',
  gold: '#c9a24a',
  goldDim: '#9c7e3c',
  sand: '#ead9b2',
  parchment: '#d9c498',
  red: '#8c2f1f',
};

// Area aman untuk TikTok/Reels
export const SAFE_TOP = 170;
export const SAFE_BOTTOM = 320;
