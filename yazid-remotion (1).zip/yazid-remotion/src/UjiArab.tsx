import React from 'react';
import {AbsoluteFill} from 'remotion';
import {ArabicText} from './components/ArabicQuote';
import {arab} from './config';
import {C} from './theme';

// Uji bentuk huruf Arab: semua huruf harus tersambung benar dan urutan kanan-ke-kiri.
export const UjiArab: React.FC = () => (
  <AbsoluteFill style={{background: '#14100a', padding: 60, justifyContent: 'center', gap: 20}}>
    <ArabicText text={arab.title} size={120} color={C.gold} />
    <div style={{height: 20}} />
    <ArabicText text={arab.full} size={64} />
    <div style={{height: 20}} />
    {arab.segments.map((s, i) => (
      <ArabicText key={i} text={s} size={64} />
    ))}
  </AbsoluteFill>
);
