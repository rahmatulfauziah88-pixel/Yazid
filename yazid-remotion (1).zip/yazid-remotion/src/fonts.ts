import {loadFont as loadAmiri} from '@remotion/google-fonts/Amiri';
import {loadFont as loadCinzel} from '@remotion/google-fonts/Cinzel';
import {loadFont as loadCormorant} from '@remotion/google-fonts/CormorantGaramond';

const amiri = loadAmiri('normal', {weights: ['400', '700'], subsets: ['arabic', 'latin']});
const cinzel = loadCinzel('normal', {weights: ['400', '700'], subsets: ['latin']});
const cormorant = loadCormorant('italic', {weights: ['500', '600'], subsets: ['latin']});

export const FONT_ARAB = amiri.fontFamily;
export const FONT_TITLE = cinzel.fontFamily;
export const FONT_BODY = cormorant.fontFamily;
