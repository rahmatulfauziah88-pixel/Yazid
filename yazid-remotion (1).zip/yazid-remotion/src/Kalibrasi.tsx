import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';
import {C, H, W} from './theme';
import {FONT_TITLE} from './fonts';
import {IMG, PLACES, PlaceId, geoNorm, placeNorm} from './config';

// Gambar peta + garis lintang/bujur (hasil transformasi) + titik lokasi, untuk memeriksa posisi.
export const MapKalibrasi: React.FC = () => {
  const lons = [34, 36, 38, 40, 42, 44, 46, 48, 50, 52];
  const lats = [14, 18, 22, 26, 30, 34, 38];
  const pt = (lat: number, lon: number) => {
    const n = geoNorm(lat, lon);
    return {x: n.x * W, y: n.y * H};
  };
  const ids: PlaceId[] = ['damaskus', 'karbala', 'madinah', 'makkah', 'harrah'];
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Img src={staticFile(IMG.peta)} style={{width: W, height: H, objectFit: 'cover'}} />
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        {lons.map((l) => {
          const a = pt(10, l), b = pt(40, l);
          return <line key={'o' + l} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="rgba(255,255,0,0.6)" strokeWidth={2} />;
        })}
        {lats.map((l) => {
          const a = pt(l, 32), b = pt(l, 54);
          return <line key={'a' + l} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="rgba(0,255,255,0.6)" strokeWidth={2} />;
        })}
      </svg>
      {lons.map((l) => {
        const p = pt(36, l);
        return <div key={'ot' + l} style={{position: 'absolute', left: p.x, top: p.y, color: '#ff0', fontSize: 26, fontFamily: FONT_TITLE, textShadow: '0 0 6px #000'}}>{l}E</div>;
      })}
      {lats.map((l) => {
        const p = pt(l, 50);
        return <div key={'at' + l} style={{position: 'absolute', left: p.x - 60, top: p.y, color: '#0ff', fontSize: 26, fontFamily: FONT_TITLE, textShadow: '0 0 6px #000'}}>{l}N</div>;
      })}
      {ids.map((id) => {
        const p = placeNorm(id);
        return (
          <div key={id} style={{position: 'absolute', left: p.x * W, top: p.y * H}}>
            <div style={{position: 'absolute', left: -14, top: -14, width: 28, height: 28, borderRadius: '50%', background: 'red', border: '3px solid #fff'}} />
            <div style={{position: 'absolute', left: 22, top: -18, color: '#fff', fontSize: 34, fontFamily: FONT_TITLE, fontWeight: 700, textShadow: '0 0 8px #000, 0 0 8px #000'}}>{PLACES[id].label}</div>
          </div>
        );
      })}
      <div style={{position: 'absolute', bottom: 40, left: 20, right: 20, color: C.sand, fontSize: 26, fontFamily: FONT_TITLE, textShadow: '0 0 8px #000', background: 'rgba(0,0,0,0.6)', padding: 12}}>
        Titik merah harus berada di kota aslinya. Jika meleset, atur MANUAL_POS di src/config.ts.
      </div>
    </AbsoluteFill>
  );
};
