import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useVideoConfig} from 'remotion';
import {AUDIO_FILE, OVERLAP, buildTimeline} from './config';
import {Scene1Hook} from './scenes/Scene1Hook';
import {Scene2Yazid} from './scenes/Scene2Yazid';
import {Scene3Karbala} from './scenes/Scene3Karbala';
import {Scene4Thabari} from './scenes/Scene4Thabari';
import {Scene5Harrah} from './scenes/Scene5Harrah';
import {Scene6Suyuthi} from './scenes/Scene6Suyuthi';
import {Scene7Makkah} from './scenes/Scene7Makkah';
import {Scene8Penutup} from './scenes/Scene8Penutup';

const SCENES: React.FC<{dur: number}>[] = [
  Scene1Hook,
  Scene2Yazid,
  Scene3Karbala,
  Scene4Thabari,
  Scene5Harrah,
  Scene6Suyuthi,
  Scene7Makkah,
  Scene8Penutup,
];

export const Video: React.FC = () => {
  const {durationInFrames} = useVideoConfig();
  const timeline = buildTimeline(durationInFrames);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Audio src={staticFile(AUDIO_FILE)} />
      {SCENES.map((Scene, i) => {
        const {start, dur} = timeline[i];
        const last = i === SCENES.length - 1;
        return (
          <Sequence key={i} from={start} durationInFrames={dur + (last ? 0 : OVERLAP)} name={`Adegan ${i + 1}`}>
            <CrossFade first={i === 0}>
              <Scene dur={dur} />
            </CrossFade>
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

import {interpolate, useCurrentFrame} from 'remotion';
const CrossFade: React.FC<{first: boolean; children: React.ReactNode}> = ({first, children}) => {
  const frame = useCurrentFrame();
  const o = first ? 1 : interpolate(frame, [0, OVERLAP], [0, 1], {extrapolateRight: 'clamp'});
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};
