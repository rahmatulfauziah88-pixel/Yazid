import arab from './data/arab.json';
import {FPS, H, W} from './theme';

export {arab};

// ---------- ASET ----------
export const AUDIO_FILE = 'audio/AUD-20261102-WA0013.mp3';
export const FALLBACK_SECONDS = 100; // dipakai hanya jika durasi audio gagal dibaca
export const TAIL_FRAMES = 30; // jeda hening di akhir setelah narasi selesai
export const OVERLAP = 18; // crossfade antar adegan (frame)

export const IMG = {
  peta: 'images/1000520810.jpg',
  damaskus: 'images/1000520811.jpg',
  kemah: 'images/1000520814.jpg',
  pasukan: 'images/1000520815.jpg',
  permukiman: 'images/1000520816.jpg',
  kotaDitinggal: 'images/1000520817.jpg',
  kaabah: 'images/1000520818.jpg',
  makkah: 'images/1000520819.jpg',
  perkamen: 'images/1000520820.jpg',
};

// ---------- NASKAH (TIDAK DIUBAH) ----------
// Dipakai untuk membagi durasi audio per adegan secara proporsional.
export const NASKAH: string[] = [
  // 1
  'Bayangkan... Cucu Rasulullah ﷺ terbunuh. Kota Madinah diserang. Bahkan, kota suci Makkah mengalami pengepungan. Semua itu terjadi pada masa pemerintahan seorang penguasa bernama Yazid bin Muawiyah.',
  // 2
  'Tahun 60 Hijriah, Yazid naik menjadi penguasa setelah wafatnya Muawiyah. Penolakan terhadap kepemimpinannya memicu pergolakan besar di dunia Islam.',
  // 3
  'Tahun 61 Hijriah, di Karbala, Sayyidina Husain bin Ali, cucu Rasulullah ﷺ, bersama keluarga dan pengikutnya dihadang pasukan. Pada hari Asyura, Sayyidina Husain terbunuh bersama sejumlah anggota keluarganya dan para pengikutnya.',
  // 4
  'Imam al-Thabari mencatat tragedi ini secara panjang dalam kitab Tarikh al-Rusul wa al-Muluk. Namun, tragedi belum berakhir.',
  // 5
  'Tahun 63 Hijriah, Madinah mengalami peristiwa al-Harrah. Pasukan Syam yang dikirim Yazid, di bawah pimpinan Muslim bin Uqbah, menyerang penduduk Madinah. Pembunuhan dan penjarahan pun terjadi.',
  // 6
  'Imam Jalaluddin al-Suyuthi dalam Tarikh al-Khulafa mencatat bahwa penduduk Madinah memberontak karena Yazid banyak melakukan kemaksiatan. Beliau juga mengutip riwayat tentang tuduhan meminum khamr dan meninggalkan salat. Al-Dzahabi, sebagaimana dikutip al-Suyuthi, turut menyebut kemaksiatan dan kemungkaran yang dikaitkan dengan Yazid.',
  // 7
  'Belum selesai di sana, pasukannya bergerak mengepung Makkah untuk menghadapi Sayyidina Abdullah bin Zubair. Ka\'bah mengalami kerusakan akibat kebakaran dan serangan selama pengepungan.',
  // 8
  'Tahun 64 Hijriah, Yazid meninggal dunia. Namun, luka sejarah dari masa pemerintahannya tetap dikenang. Menurut kalian, bagaimana kita harus memahami sejarah ini? Tuliskan pendapat dan referensi kitab yang kalian miliki di kolom komentar. Jangan lupa like, bagikan, dan ikuti agar kita terus belajar sejarah Islam berdasarkan sumber, bukan sekadar cerita. Karena sejarah tidak boleh dilupakan.',
];

// Tambahan bobot (setara jumlah kata) untuk adegan yang butuh waktu baca ekstra (teks Arab).
export const EXTRA_WEIGHT: Record<number, number> = {5: 14};

// Detik awal tiap adegan (8 angka). Ubah jika ingin menggeser; isi null untuk pembagian otomatis per jumlah kata.
// Hasil deteksi jeda pada AUD-20261102-WA0013.mp3 (113,8 dtk): awal tiap adegan jatuh di tengah jeda antar kalimat.
export const MANUAL_START_SECONDS: number[] | null = [0, 14.7, 23.87, 39.7, 47.7, 57.25, 78.5, 88.83];

export type SceneTime = {start: number; dur: number};

const countWords = (s: string) => s.trim().split(/\s+/).length;

export function buildTimeline(totalFrames: number): SceneTime[] {
  const narrFrames = Math.max(1, totalFrames - TAIL_FRAMES);
  let starts: number[];
  if (MANUAL_START_SECONDS && MANUAL_START_SECONDS.length === NASKAH.length) {
    starts = MANUAL_START_SECONDS.map((s) => Math.round(s * FPS));
  } else {
    const weights = NASKAH.map((t, i) => countWords(t) + (EXTRA_WEIGHT[i] ?? 0));
    const sum = weights.reduce((a, b) => a + b, 0);
    let acc = 0;
    starts = weights.map((w) => {
      const s = Math.round((acc / sum) * narrFrames);
      acc += w;
      return s;
    });
  }
  return starts.map((start, i) => ({
    start,
    dur: (i < starts.length - 1 ? starts[i + 1] : totalFrames) - start,
  }));
}

// ---------- GEOGRAFI PETA ----------
export type PlaceId = 'damaskus' | 'karbala' | 'madinah' | 'makkah' | 'harrah';

// Koordinat nyata (lintang, bujur). Al-Harrah = kawasan harrah (lahar) di timur Madinah, perkiraan.
export const PLACES: Record<PlaceId, {lat: number; lon: number; label: string; sub?: string}> = {
  damaskus: {lat: 33.5138, lon: 36.2765, label: 'DAMASKUS', sub: 'SYAM'},
  karbala: {lat: 32.616, lon: 44.024, label: 'KARBALA', sub: 'IRAK'},
  madinah: {lat: 24.4672, lon: 39.6111, label: 'MADINAH', sub: 'HIJAZ'},
  makkah: {lat: 21.4225, lon: 39.8262, label: 'MAKKAH', sub: 'HIJAZ'},
  harrah: {lat: 24.5, lon: 39.74, label: 'AL-HARRAH', sub: 'perkiraan kawasan'},
};

// Transformasi lintang/bujur -> piksel pada gambar asli 1000520810.jpg (1438x2576).
// Peta ini berupa foto udara yang miring (Laut Merah tampak vertikal), jadi dipakai transformasi
// affine hasil pencocokan titik nyata (Teluk Suez/Aqaba, Sinai, Teluk Persia, Qatar, Bab el-Mandeb,
// Laut Mati, danau Tharthar/Razzaza). Galat sekitar 1-3%. Cek dengan `npm run kalibrasi`.
export const MAP_AFFINE = {
  ax: 69.133, bx: 27.945, cx: -2927.724,
  ay: 19.166, by: -78.44, cy: 2364.674,
  imgW: 1438, imgH: 2576,
};

// Jika ada titik yang masih meleset, timpa langsung (0-1 dari kiri/atas layar peta).
export const MANUAL_POS: Partial<Record<PlaceId, {x: number; y: number}>> = {};

// Hasil: koordinat 0-1 pada kanvas 1080x1920 (gambar di-cover, jadi sedikit terpotong vertikal).
export function geoNorm(lat: number, lon: number) {
  const m = MAP_AFFINE;
  const px = m.ax * lon + m.bx * lat + m.cx;
  const py = m.ay * lon + m.by * lat + m.cy;
  const scale = W / m.imgW;
  const fullH = m.imgH * scale;
  return {x: px / m.imgW, y: (py * scale - (fullH - H) / 2) / H};
}

export function placeNorm(id: PlaceId): {x: number; y: number} {
  const m = MANUAL_POS[id];
  if (m) return m;
  const p = PLACES[id];
  return geoNorm(p.lat, p.lon);
}
