import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, H, W} from '../theme';
import {FONT_BODY, FONT_TITLE} from '../fonts';
import {IMG, PLACES, PlaceId, placeNorm} from '../config';
import {Dust, Fog, Grain, Vignette} from './Atmos';

export type CamKey = {t: number; at: {x: number; y: number}; z: number};
export type MarkerDef = {id: PlaceId; at: number; ring?: boolean; hideSub?: boolean; side?: 'left' | 'right'};
export type RouteDef = {from: PlaceId; to: PlaceId; start: number; end: number; bend?: number};

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export const useCamera = (keys: CamKey[]) => {
  const frame = useCurrentFrame();
  const ts = keys.map((k) => k.t);
  const opt = {easing: Easing.inOut(Easing.cubic), extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
  const fx = interpolate(frame, ts, keys.map((k) => k.at.x), opt);
  const fy = interpolate(frame, ts, keys.map((k) => k.at.y), opt);
  const z = interpolate(frame, ts, keys.map((k) => k.z), opt);
  const tx = clamp(W / 2 - fx * W * z, W - W * z, 0);
  const ty = clamp(H / 2 - fy * H * z, H - H * z, 0);
  return {z, tx, ty};
};

const PinMarker: React.FC<{def: MarkerDef; z: number}> = ({def, z}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = PLACES[def.id];
  const pos = placeNorm(def.id);
  const local = frame - def.at;
  if (local < 0) return null;
  const s = spring({frame: local, fps, config: {damping: 12, stiffness: 120}});
  const pulse = (frame % 60) / 60;
  const side = def.side ?? (pos.x > 0.62 ? 'left' : 'right');
  const labelOpacity = interpolate(local, [8, 24], [0, 1], {extrapolateRight: 'clamp'});

  if (def.ring) {
    return (
      <div style={{position: 'absolute', left: pos.x * W, top: pos.y * H, transform: `scale(${1 / z})`}}>
        <div
          style={{
            position: 'absolute',
            width: 150,
            height: 150,
            left: -75,
            top: -75,
            borderRadius: '50%',
            border: `4px dashed ${C.gold}`,
            transform: `scale(${s}) rotate(${frame * 0.6}deg)`,
            boxShadow: '0 0 40px rgba(201,162,74,0.5)',
          }}
        />
        <div
          style={{
            position: 'absolute',
            top: 92,
            left: -200,
            width: 400,
            textAlign: 'center',
            opacity: labelOpacity,
            fontFamily: FONT_TITLE,
            fontWeight: 700,
            fontSize: 34,
            color: C.gold,
            letterSpacing: 5,
            textShadow: '0 2px 10px #000, 0 0 18px #000',
          }}
        >
          {p.label}
        </div>
      </div>
    );
  }

  return (
    <div style={{position: 'absolute', left: pos.x * W, top: pos.y * H, transform: `scale(${1 / z})`}}>
      <div
        style={{
          position: 'absolute',
          width: 120,
          height: 120,
          left: -60,
          top: -60,
          borderRadius: '50%',
          border: `3px solid ${C.gold}`,
          opacity: (1 - pulse) * 0.9 * s,
          transform: `scale(${0.3 + pulse * 1.1})`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          width: 34,
          height: 34,
          left: -17,
          top: -17,
          borderRadius: '50%',
          background: `radial-gradient(circle, #fff3c4, ${C.gold})`,
          border: '3px solid #2a1b10',
          boxShadow: '0 0 30px 10px rgba(255,200,90,0.55)',
          transform: `scale(${s})`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: -44,
          [side === 'right' ? 'left' : 'right']: 40,
          opacity: labelOpacity,
          textAlign: side === 'right' ? 'left' : 'right',
          whiteSpace: 'nowrap',
          textShadow: '0 2px 12px #000, 0 0 22px #000',
        }}
      >
        <div style={{fontFamily: FONT_TITLE, fontWeight: 700, fontSize: 46, color: C.sand, letterSpacing: 5}}>
          {p.label}
        </div>
        {!def.hideSub && p.sub && (
          <div style={{fontFamily: FONT_BODY, fontStyle: 'italic', fontWeight: 600, fontSize: 34, color: C.gold}}>
            {p.sub}
          </div>
        )}
      </div>
    </div>
  );
};

const Route: React.FC<{def: RouteDef; z: number}> = ({def, z}) => {
  const frame = useCurrentFrame();
  const a = placeNorm(def.from);
  const b = placeNorm(def.to);
  const ax = a.x * W, ay = a.y * H, bx = b.x * W, by = b.y * H;
  const mx = (ax + bx) / 2, my = (ay + by) / 2;
  const dx = bx - ax, dy = by - ay;
  const len = Math.hypot(dx, dy);
  const bend = def.bend ?? 0.18;
  const cx = mx - (dy / len) * len * bend;
  const cy = my + (dx / len) * len * bend;
  const prog = interpolate(frame, [def.start, def.end], [0, 1], {
    easing: Easing.inOut(Easing.quad),
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  if (frame < def.start) return null;
  const pt = (t: number) => ({
    x: (1 - t) ** 2 * ax + 2 * (1 - t) * t * cx + t * t * bx,
    y: (1 - t) ** 2 * ay + 2 * (1 - t) * t * cy + t * t * by,
  });
  const head = pt(prog);
  const before = pt(Math.max(0, prog - 0.02));
  const ang = (Math.atan2(head.y - before.y, head.x - before.x) * 180) / Math.PI;
  return (
    <>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
        <path
          d={`M ${ax} ${ay} Q ${cx} ${cy} ${bx} ${by}`}
          pathLength={1}
          fill="none"
          stroke={C.gold}
          strokeWidth={7 / z}
          strokeLinecap="round"
          strokeDasharray={`${prog} 1`}
          style={{filter: 'drop-shadow(0 0 10px rgba(255,200,90,0.9))'}}
        />
      </svg>
      <div
        style={{
          position: 'absolute',
          left: head.x,
          top: head.y,
          transform: `translate(-50%,-50%) rotate(${ang}deg) scale(${1 / z})`,
          width: 0,
          height: 0,
          borderTop: '16px solid transparent',
          borderBottom: '16px solid transparent',
          borderLeft: `30px solid ${C.gold}`,
          filter: 'drop-shadow(0 0 10px rgba(255,200,90,0.9))',
        }}
      />
    </>
  );
};

export const RegionLabel: React.FC<{text: string; x: number; y: number; at: number; z: number}> = ({text, x, y, at, z}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [at, at + 24], [0, 0.85], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div
      style={{
        position: 'absolute',
        left: x * W,
        top: y * H,
        transform: `translate(-50%,-50%) scale(${1 / z})`,
        opacity: o,
        fontFamily: FONT_TITLE,
        fontSize: 92,
        fontWeight: 700,
        letterSpacing: 28,
        color: 'rgba(234,217,178,0.8)',
        textShadow: '0 4px 20px #000',
        whiteSpace: 'nowrap',
      }}
    >
      {text}
    </div>
  );
};

export const MapLayer: React.FC<{
  cam: CamKey[];
  markers?: MarkerDef[];
  routes?: RouteDef[];
  regions?: {text: string; x: number; y: number; at: number}[];
  dim?: {from: number; to: number; level: number};
  grain?: boolean;
}> = ({cam, markers = [], routes = [], regions = [], dim, grain = true}) => {
  const frame = useCurrentFrame();
  const {z, tx, ty} = useCamera(cam);
  const dimOpacity = dim ? interpolate(frame, [dim.from, dim.to], [0, dim.level], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
  return (
    <AbsoluteFill style={{background: C.black, overflow: 'hidden'}}>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: H,
          transformOrigin: '0 0',
          transform: `translate(${tx}px, ${ty}px) scale(${z})`,
        }}
      >
        <Img
          src={staticFile(IMG.peta)}
          style={{width: W, height: H, objectFit: 'cover', filter: 'sepia(0.55) saturate(0.85) brightness(0.78) contrast(1.12)'}}
        />
        {regions.map((r) => (
          <RegionLabel key={r.text} {...r} z={z} />
        ))}
        {routes.map((r, i) => (
          <Route key={i} def={r} z={z} />
        ))}
        {markers.map((m) => (
          <PinMarker key={m.id + m.at} def={m} z={z} />
        ))}
      </div>
      <Fog opacity={0.3} />
      <Dust count={18} opacity={0.35} />
      <Vignette strength={0.7} />
      {grain && <Grain />}
      <AbsoluteFill style={{background: '#000', opacity: dimOpacity}} />
    </AbsoluteFill>
  );
};
