import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {FONT_ARAB, FONT_BODY} from '../fonts';

// PENTING: jangan beri letterSpacing/wordSpacing pada teks Arab (merusak penyambungan huruf).
export const ArabicText: React.FC<{text: string; size?: number; color?: string; glow?: boolean}> = ({
  text,
  size = 70,
  color = C.sand,
  glow = false,
}) => (
  <div
    dir="rtl"
    lang="ar"
    style={{
      fontFamily: FONT_ARAB,
      fontSize: size,
      lineHeight: 1.85,
      color,
      textAlign: 'center',
      direction: 'rtl',
      unicodeBidi: 'isolate',
      fontKerning: 'normal',
      fontFeatureSettings: '"liga" 1, "calt" 1, "kern" 1',
      textShadow: glow ? '0 0 26px rgba(255,200,90,0.75), 0 2px 8px #000' : '0 2px 8px #000',
      letterSpacing: 0,
      wordSpacing: 0,
    }}
  >
    {text}
  </div>
);

// Satu "halaman" kutipan: beberapa potongan Arab muncul bertahap (yang aktif disorot lembut),
// lalu terjemahan Indonesia muncul setelahnya.
export const QuotePage: React.FC<{
  segments: string[];
  translation: string;
  dur: number;
}> = ({segments, translation, dur}) => {
  const frame = useCurrentFrame();
  const n = segments.length;
  const arabEnd = dur * 0.58;
  const step = arabEnd / n;
  const tIn = interpolate(frame, [arabEnd, arabEnd + 14], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div
      style={{
        position: 'absolute',
        left: 60,
        right: 60,
        top: 330,
        minHeight: 1000,
        padding: '48px 40px',
        background: 'rgba(14,9,4,0.66)',
        border: `2px solid ${C.goldDim}`,
        boxShadow: '0 0 60px rgba(0,0,0,0.7)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        gap: 10,
      }}
    >
      {segments.map((seg, i) => {
        const start = i * step;
        const o = interpolate(frame, [start, start + 16], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        const y = interpolate(frame, [start, start + 16], [18, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        const active = frame >= start && frame < start + step;
        const dimmed = frame >= start + step;
        return (
          <div key={i} style={{opacity: o * (dimmed ? 0.62 : 1), transform: `translateY(${y}px)`}}>
            <ArabicText text={seg} glow={active} color={active ? '#fff3cf' : C.sand} />
          </div>
        );
      })}
      <div style={{height: 2, margin: '18px 120px', background: `linear-gradient(90deg, transparent, ${C.gold}, transparent)`, opacity: tIn}} />
      <div
        style={{
          opacity: tIn,
          fontFamily: FONT_BODY,
          fontStyle: 'italic',
          fontWeight: 600,
          fontSize: 44,
          lineHeight: 1.35,
          color: C.sand,
          textAlign: 'center',
        }}
      >
        {translation}
      </div>
    </div>
  );
};
