import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, random, staticFile, useCurrentFrame} from 'remotion';
import {C, H, W} from '../theme';
import {IMG} from '../config';
import {Dust, Grain, Vignette} from './Atmos';

// Kitab terbuka di atas meja kayu, dibangun murni dengan CSS (tanpa gambar kitab, tanpa teks Arab palsu).
// Halaman hanya memuat garis-garis samar sebagai tanda "teks", bukan huruf.
const PageLines: React.FC<{seed: string}> = ({seed}) => (
  <div style={{position: 'absolute', inset: '70px 80px', display: 'flex', flexDirection: 'column', gap: 26, opacity: 0.35}}>
    {Array.from({length: 17}).map((_, i) => (
      <div
        key={i}
        style={{
          height: 9,
          borderRadius: 5,
          background: '#3b2713',
          width: `${i % 6 === 5 ? 55 : 82 + random(seed + i) * 18}%`,
          alignSelf: 'flex-end',
          filter: 'blur(1.2px)',
        }}
      />
    ))}
  </div>
);

const Page: React.FC<{seed: string; top?: boolean}> = ({seed, top}) => (
  <div
    style={{
      position: 'relative',
      width: 900,
      height: 600,
      overflow: 'hidden',
      borderRadius: top ? '10px 10px 0 0' : '0 0 10px 10px',
    }}
  >
    <Img src={staticFile(IMG.perkamen)} style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'sepia(0.6) brightness(0.92) contrast(1.05)'}} />
    <PageLines seed={seed} />
    <div
      style={{
        position: 'absolute',
        inset: 0,
        background: top
          ? 'linear-gradient(to bottom, rgba(0,0,0,0.0) 70%, rgba(40,20,5,0.55) 100%)'
          : 'linear-gradient(to top, rgba(0,0,0,0.0) 70%, rgba(40,20,5,0.55) 100%)',
      }}
    />
  </div>
);

export const Book: React.FC<{
  dur: number;
  zoomTo?: number;
  children?: React.ReactNode;
  darken?: {from: number; to: number; level: number};
}> = ({dur, zoomTo = 1.5, children, darken}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, dur], [0, 1], {easing: Easing.inOut(Easing.cubic), extrapolateRight: 'clamp'});
  const scale = 0.92 + (zoomTo - 0.92) * p;
  const tilt = 24 * (1 - p);
  const flick = 0.82 + 0.08 * Math.sin(frame / 7) + 0.06 * random(`fl${Math.floor(frame / 3)}`);
  const dk = darken ? interpolate(frame, [darken.from, darken.to], [0, darken.level], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
  return (
    <AbsoluteFill style={{background: C.black, overflow: 'hidden'}}>
      {/* meja kayu */}
      <AbsoluteFill
        style={{
          background:
            'repeating-linear-gradient(90deg, rgba(0,0,0,0.22) 0 2px, rgba(0,0,0,0) 2px 11px), linear-gradient(180deg, #3b2412, #26160a 60%, #1a0f06)',
        }}
      />
      <AbsoluteFill style={{opacity: 0.35, mixBlendMode: 'multiply'}}>
        <svg width={W} height={H}>
          <filter id="wood">
            <feTurbulence type="fractalNoise" baseFrequency="0.012 0.5" numOctaves={3} seed={7} />
            <feColorMatrix type="saturate" values="0" />
          </filter>
          <rect width={W} height={H} filter="url(#wood)" />
        </svg>
      </AbsoluteFill>
      {/* buku */}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', perspective: 1800}}>
        <div
          style={{
            transform: `scale(${scale}) rotateX(${tilt}deg) rotateZ(${-3 * (1 - p)}deg)`,
            transformStyle: 'preserve-3d',
            filter: 'drop-shadow(0 40px 50px rgba(0,0,0,0.8))',
          }}
        >
          <div style={{padding: 14, background: '#4a2c14', borderRadius: 16, boxShadow: 'inset 0 0 0 3px #2a1608'}}>
            <div style={{boxShadow: '0 6px 0 -2px #b8a272, 0 12px 0 -4px #a89262'}}>
              <Page seed="a" top />
              <div style={{height: 14, background: 'linear-gradient(to bottom, #2a1608, #5a3a1c 50%, #2a1608)'}} />
              <Page seed="b" />
            </div>
          </div>
        </div>
      </AbsoluteFill>
      {/* cahaya hangat dari samping */}
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at 6% 38%, rgba(255,185,100,${0.55 * flick}), rgba(255,185,100,0) 62%)`,
          mixBlendMode: 'screen',
        }}
      />
      <Dust count={26} opacity={0.45} />
      <Vignette strength={0.85} />
      <Grain />
      <AbsoluteFill style={{background: '#000', opacity: dk}} />
      {children}
    </AbsoluteFill>
  );
};
