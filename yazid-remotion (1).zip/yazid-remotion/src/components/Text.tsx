import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, SAFE_BOTTOM, SAFE_TOP} from '../theme';
import {FONT_BODY, FONT_TITLE} from '../fonts';

const glow = '0 0 28px rgba(0,0,0,0.9), 0 3px 10px rgba(0,0,0,0.9)';

export const TitleText: React.FC<{
  text: string;
  size?: number;
  color?: string;
  spacing?: number;
  pop?: boolean;
}> = ({text, size = 92, color = C.sand, spacing = 8, pop = true}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = pop ? spring({frame, fps, config: {damping: 200}}) : 1;
  const sc = interpolate(s, [0, 1], [0.92, 1]);
  const reveal = interpolate(frame, [0, 22], [spacing + 14, spacing], {extrapolateRight: 'clamp'});
  return (
    <div
      style={{
        fontFamily: FONT_TITLE,
        fontWeight: 700,
        fontSize: size,
        color,
        letterSpacing: reveal,
        textAlign: 'center',
        textShadow: glow,
        transform: `scale(${sc})`,
        lineHeight: 1.18,
        padding: '0 50px',
        opacity: s,
      }}
    >
      {text}
    </div>
  );
};

export const SubText: React.FC<{text: string; size?: number; color?: string}> = ({
  text,
  size = 46,
  color = C.sand,
}) => (
  <div
    style={{
      fontFamily: FONT_BODY,
      fontStyle: 'italic',
      fontWeight: 600,
      fontSize: size,
      color,
      textAlign: 'center',
      textShadow: glow,
      padding: '0 70px',
      lineHeight: 1.3,
    }}
  >
    {text}
  </div>
);

// Posisi: 'top' (di bawah area UI atas), 'center', 'bottom' (di atas area UI bawah)
export const Anchor: React.FC<{at: 'top' | 'center' | 'bottom'; children: React.ReactNode; offset?: number}> = ({
  at,
  children,
  offset = 0,
}) => {
  const style: React.CSSProperties = {
    position: 'absolute',
    left: 0,
    right: 0,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 14,
  };
  if (at === 'top') style.top = SAFE_TOP + offset;
  if (at === 'bottom') style.bottom = SAFE_BOTTOM + offset;
  if (at === 'center') {
    style.top = 0;
    style.bottom = 0;
    style.justifyContent = 'center';
    style.marginTop = offset;
  }
  return <div style={style}>{children}</div>;
};

export const GoldRule: React.FC<{width?: number}> = ({width = 420}) => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [0, 24], [0, width], {extrapolateRight: 'clamp'});
  return (
    <div
      style={{
        height: 3,
        width: w,
        background: `linear-gradient(90deg, transparent, ${C.gold}, transparent)`,
      }}
    />
  );
};

export const YearBadge: React.FC<{year: string; label?: string}> = ({year, label = 'HIJRIAH'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame, fps, config: {damping: 14, stiffness: 110}});
  return (
    <div
      style={{
        transform: `scale(${interpolate(s, [0, 1], [0.6, 1])})`,
        opacity: Math.min(1, s * 1.4),
        textAlign: 'center',
        padding: '14px 46px 16px',
        border: `2px solid ${C.gold}`,
        background: 'rgba(10,7,4,0.62)',
        boxShadow: '0 0 40px rgba(201,162,74,0.35)',
      }}
    >
      <div style={{fontFamily: FONT_TITLE, fontWeight: 700, fontSize: 118, color: C.gold, lineHeight: 1.05}}>
        {year}
      </div>
      <div style={{fontFamily: FONT_TITLE, fontSize: 26, color: C.sand, letterSpacing: 10}}>{label}</div>
    </div>
  );
};
