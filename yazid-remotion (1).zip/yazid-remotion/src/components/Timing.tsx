import React from 'react';
import {interpolate, Sequence, useCurrentFrame} from 'remotion';

// Menampilkan anak pada rentang frame lokal [from, to] dengan fade masuk/keluar.
export const Show: React.FC<{
  from: number;
  to?: number;
  fade?: number;
  children: React.ReactNode;
}> = ({from, to, fade = 14, children}) => {
  const frame = useCurrentFrame();
  if (frame < from || (to !== undefined && frame > to)) return null;
  const fin = interpolate(frame, [from, from + fade], [0, 1], {extrapolateRight: 'clamp'});
  const fout =
    to === undefined ? 1 : interpolate(frame, [to - fade, to], [1, 0], {extrapolateLeft: 'clamp'});
  return (
    <div style={{position: 'absolute', inset: 0, opacity: Math.min(fin, fout)}}>
      <Sequence from={from} durationInFrames={to !== undefined ? to - from + 1 : Infinity} layout="none">
        {children}
      </Sequence>
    </div>
  );
};

const FadeIn: React.FC<{fade: number; children: React.ReactNode}> = ({fade, children}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, fade], [0, 1], {extrapolateRight: 'clamp'});
  return <div style={{position: 'absolute', inset: 0, opacity: o}}>{children}</div>;
};

// Fase dalam adegan: tampil dari frame `from`, fade-in, bertahan sampai adegan selesai
// (fase berikutnya menutupinya).
export const Phase: React.FC<{from: number; fade?: number; children: React.ReactNode}> = ({
  from,
  fade = 18,
  children,
}) => (
  <Sequence from={from} layout="none">
    <FadeIn fade={from === 0 ? 1 : fade}>{children}</FadeIn>
  </Sequence>
);

export const fr = (dur: number, frac: number) => Math.round(dur * frac);
