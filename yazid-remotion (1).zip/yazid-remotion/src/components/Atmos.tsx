import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';
import {H, W} from '../theme';

export const Vignette: React.FC<{strength?: number}> = ({strength = 0.75}) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at 50% 48%, rgba(0,0,0,0) 38%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: 'none',
    }}
  />
);

export const Grain: React.FC<{opacity?: number}> = ({opacity = 0.09}) => {
  const frame = useCurrentFrame();
  const seed = Math.floor(frame / 2) % 12;
  return (
    <AbsoluteFill style={{opacity, mixBlendMode: 'overlay', pointerEvents: 'none'}}>
      <svg width={W} height={H}>
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves={2} seed={seed} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width={W} height={H} filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Dust: React.FC<{count?: number; opacity?: number}> = ({count = 28, opacity = 0.5}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {Array.from({length: count}).map((_, i) => {
        const x0 = random(`dx${i}`) * W;
        const y0 = random(`dy${i}`) * H;
        const sp = 0.25 + random(`ds${i}`) * 0.7;
        const size = 2 + random(`dz${i}`) * 5;
        const x = (x0 + frame * sp * 1.4 + Math.sin(frame / 40 + i) * 20) % W;
        const y = (y0 - frame * sp * 0.6 + H * 4) % H;
        const tw = 0.4 + 0.6 * Math.abs(Math.sin(frame / 25 + i * 1.7));
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: size,
              height: size,
              borderRadius: '50%',
              background: '#f0d9a0',
              opacity: opacity * tw,
              filter: 'blur(1px)',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

// Kabut tipis yang bergeser pelan
export const Fog: React.FC<{opacity?: number}> = ({opacity = 0.35}) => {
  const frame = useCurrentFrame();
  const a = interpolate(Math.sin(frame / 90), [-1, 1], [-160, 160]);
  const b = interpolate(Math.cos(frame / 120), [-1, 1], [-200, 200]);
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity}}>
      <div
        style={{
          position: 'absolute',
          left: -300 + a,
          top: 300,
          width: 1700,
          height: 520,
          background: 'radial-gradient(ellipse, rgba(230,205,160,0.55), rgba(230,205,160,0) 70%)',
          filter: 'blur(40px)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: -400 + b,
          top: 1100,
          width: 1800,
          height: 600,
          background: 'radial-gradient(ellipse, rgba(200,170,120,0.5), rgba(200,170,120,0) 70%)',
          filter: 'blur(50px)',
        }}
      />
    </AbsoluteFill>
  );
};

export const Letterbox: React.FC = () => (
  <>
    <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 90, background: '#000'}} />
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 90, background: '#000'}} />
  </>
);
