import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {H, W} from '../theme';
import {Dust, Grain, Vignette} from './Atmos';

export type Move = {s: number; x: number; y: number};

// Ken Burns + parallax dua lapis (lapisan bawah bergerak lebih cepat) + debu + cahaya hangat.
export const Illustration: React.FC<{
  src: string;
  dur: number;
  from: Move;
  to: Move;
  enterZoom?: number;
  warm?: number;
  children?: React.ReactNode;
}> = ({src, dur, from, to, enterZoom = 0.18, warm = 0.18, children}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, Math.max(1, dur)], [0, 1], {
    easing: Easing.inOut(Easing.sin),
    extrapolateRight: 'clamp',
  });
  const enter = interpolate(frame, [0, 26], [enterZoom, 0], {
    easing: Easing.out(Easing.cubic),
    extrapolateRight: 'clamp',
  });
  const s = from.s + (to.s - from.s) * p + enter;
  const x = from.x + (to.x - from.x) * p;
  const y = from.y + (to.y - from.y) * p;
  const layer = (k: number): React.CSSProperties => ({
    position: 'absolute',
    inset: 0,
    transform: `translate(${x * k}px, ${y * k}px) scale(${s + (k - 1) * 0.05})`,
  });
  return (
    <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
      <div style={layer(1)}>
        <Img src={staticFile(src)} style={{width: W, height: H, objectFit: 'cover', filter: 'sepia(0.35) saturate(0.9) brightness(0.88) contrast(1.08)'}} />
      </div>
      <div
        style={{
          ...layer(1.8),
          WebkitMaskImage: 'linear-gradient(to top, #000 0%, #000 22%, transparent 52%)',
          maskImage: 'linear-gradient(to top, #000 0%, #000 22%, transparent 52%)',
        }}
      >
        <Img src={staticFile(src)} style={{width: W, height: H, objectFit: 'cover', filter: 'sepia(0.35) saturate(0.9) brightness(0.88) contrast(1.08)'}} />
      </div>
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at 18% 8%, rgba(255,190,110,${warm}), rgba(255,190,110,0) 60%)`,
          mixBlendMode: 'screen',
        }}
      />
      <AbsoluteFill style={{background: 'linear-gradient(to top, rgba(0,0,0,0.78) 0%, rgba(0,0,0,0) 38%)'}} />
      <Dust count={22} opacity={0.4} />
      <Vignette strength={0.65} />
      <Grain />
      {children}
    </AbsoluteFill>
  );
};
